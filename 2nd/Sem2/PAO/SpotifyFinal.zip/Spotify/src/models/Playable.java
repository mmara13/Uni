package models;

public interface Playable {
    void play();
}
