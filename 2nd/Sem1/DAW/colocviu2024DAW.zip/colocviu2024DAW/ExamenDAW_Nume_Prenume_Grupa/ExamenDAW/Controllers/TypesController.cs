﻿using ExamenDAW.Models;
using Microsoft.AspNetCore.Mvc;

namespace ExamenDAW.Controllers
{
    public class TypesController : Controller
    {
        private readonly AppDbContext db;
        public TypesController(AppDbContext context)
        {
            db = context;
        }
        public IActionResult Index()
        {
            

            return View();
        }
    }
}
