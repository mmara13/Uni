﻿using ExamenDAW.Models;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.Rendering;
using Microsoft.EntityFrameworkCore;

namespace ExamenDAW.Controllers
{
    public class VouchersController : Controller
    {
        private readonly AppDbContext db;
        public VouchersController(AppDbContext context)
        {
            db = context;
        }
        public IActionResult Index()
        {
            var vouchers = db.Vouchers.Include("Type")
                                      .OrderByDescending(a => a.Suma);
            ViewBag.Vouchers = vouchers; //trimitem in view voucherele

            if (TempData.ContainsKey("message"))
            {
                ViewBag.Message = TempData["message"];
            }
            return View();
        }

        public IActionResult CautareVouchere()
        {
            var vouchers = db.Vouchers.Include("Type")
                                      .OrderBy(a => a.Suma);
            var search = "";

            //motor de cautare
            /*Am incercat sa fac motorul de cautare dar nu a iesit, pentru ca nu am avut timp sa il termin si nu eram nici stapana pe idee,
             * link-ul exista, ideea exista, dar nu e dusa la capat
             * Am incercat sa iau cele doua inputuri de tip int (si cred ca prima problema a fost ca nu am stiut exact cum sa le folosesc)
             * teoretic am ordonat rezultatele descrescator dupa suma si crescator dupa denumirea tipului*/
            if (Convert.ToString(HttpContext.Request.Query["search"]) != null)
            {
                search = Convert.ToString(HttpContext.Request.Query["search"]).Trim(); // eliminam spatiile libere 

                int searchInt;
                bool isNumeric = int.TryParse(search, out searchInt);

                List<int> voucherIds = db.Vouchers
                    .Where((v => v.Suma >= Convert.ToInt32(search) && v.Suma <= Convert.ToInt32(searchInt)))
                    .OrderByDescending(v => v.Suma) //descrescator dupa suma
                    .OrderBy(v => v.Type) //crescator dupa denumirea tipului
                    .Select(a => a.Id)
                    .ToList();

                vouchers = db.Vouchers.Where(v => voucherIds.Contains(v.Id))
                                      .Include("Type")
                                      .OrderByDescending(a => a.Suma);

                
            }

            return View();
        }

        //implicit HttpGet ia informatiile existente
        public IActionResult New()
        {
            Voucher voucher = new Voucher();

            voucher.Tip = GetAllTypes();

            return View(voucher);
        }


        //se adauga voucherul in baza de date
        [HttpPost]
        public IActionResult New(Voucher voucher)
        {
            voucher.Tip = GetAllTypes();
            if(voucher.Suma < 0)
            {
                ModelState.AddModelError("Suma", "Suma nu poate fi numar negativ");
            }
            if (voucher.DataExpirare <= DateTime.Now)
            {
                ModelState.AddModelError("DataExpirare", "Data expirarii nu poate fi in trecut.");
            }

            if (ModelState.IsValid)
            {
                db.Vouchers.Add(voucher); 
                db.SaveChanges();
                TempData["message"] = "voucherul a fost adaugat";
                return RedirectToAction("Index");
            }
            else
            {
                voucher.Tip = GetAllTypes();
                return View(voucher);
            }

        }

        public IActionResult Edit(int id)
        {
            Voucher voucher = db.Vouchers.Include("Type")
                                         .Where(v => v.Id == id)
                                         .First();

            voucher.Tip = GetAllTypes();
             
            return View(voucher);

        }

        //salvam modificarile in bd
        [HttpPost]
        public IActionResult Edit(int id, Voucher requestVoucher)
        {
            Voucher voucher = db.Vouchers.Find(id);
            requestVoucher.Tip = GetAllTypes();

            if (ModelState.IsValid)
            {
                voucher.Descriere = requestVoucher.Descriere;
                voucher.Suma = requestVoucher.Suma;
                voucher.DataExpirare = requestVoucher.DataExpirare;
                voucher.Status = requestVoucher.Status;
                TempData["message"] = "Voucherul a fost modificat cu succes!";
                db.SaveChanges();
                return RedirectToAction("Index");
            }
            else
            {
                return View(requestVoucher); //il intoarcem acolo unde era
            }
        }

        //show ca sa putem include delete
        public IActionResult Show(int id)
        {
            Voucher voucher = db.Vouchers.Include("Type")
                                         .Where(v => v.Id == id)
                                         .First();
            return View(voucher);
        }

        //stergere voucher
        [HttpPost]
        public IActionResult Delete(int id)
        {
            Voucher voucher = db.Vouchers.Include("Type")
                                         .Where(v => v.Id == id)
                                         .First();

            //stergere voucher
                db.Vouchers.Remove(voucher);
                db.SaveChanges();
                TempData["message"] = "Voucherul a fost sters";
                TempData["messageType"] = "alert-success";
                return RedirectToAction("Index");

            
        }
        public IEnumerable<SelectListItem> GetAllTypes()
        {
            // generam o lista de tipul SelectListItem fara elemente
            var selectList = new List<SelectListItem>();

            // extragem toate tipurile din baza de date
            var types = from tip in db.Types
                         select tip;

            // iteram prin tipuri
            foreach (var type in types)
            {
                // adaugam in lista elementele necesare pentru dropdown
                // id-ul tipului  si denumirea acestuia (Tip)
                selectList.Add(new SelectListItem
                {
                    Value = type.Id.ToString(),
                    Text = type.Tip.ToString()
                });
            }

            return selectList;
        }

    }
}
