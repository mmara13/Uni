﻿using Microsoft.EntityFrameworkCore.Migrations;

#nullable disable

namespace ExamenDAW.Migrations
{
    public partial class Modificare : Migration
    {
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropForeignKey(
                name: "FK_Vouchers_Types_TypeId",
                table: "Vouchers");

            migrationBuilder.AlterColumn<int>(
                name: "TypeId",
                table: "Vouchers",
                type: "int",
                nullable: true,
                oldClrType: typeof(int),
                oldType: "int");

            migrationBuilder.AddForeignKey(
                name: "FK_Vouchers_Types_TypeId",
                table: "Vouchers",
                column: "TypeId",
                principalTable: "Types",
                principalColumn: "Id");
        }

        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropForeignKey(
                name: "FK_Vouchers_Types_TypeId",
                table: "Vouchers");

            migrationBuilder.AlterColumn<int>(
                name: "TypeId",
                table: "Vouchers",
                type: "int",
                nullable: false,
                defaultValue: 0,
                oldClrType: typeof(int),
                oldType: "int",
                oldNullable: true);

            migrationBuilder.AddForeignKey(
                name: "FK_Vouchers_Types_TypeId",
                table: "Vouchers",
                column: "TypeId",
                principalTable: "Types",
                principalColumn: "Id",
                onDelete: ReferentialAction.Cascade);
        }
    }
}
