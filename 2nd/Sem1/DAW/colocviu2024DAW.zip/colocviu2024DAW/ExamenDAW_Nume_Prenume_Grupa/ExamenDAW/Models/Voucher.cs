﻿using Microsoft.AspNetCore.Mvc.Rendering;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace ExamenDAW.Models
{
    public class Voucher
    {
        [Key] //cheie primara
        public int Id { get; set; }

        [Required(ErrorMessage = "Descrierea este obligatorie")]
        [StringLength(10, ErrorMessage = "Titlul nu poate avea mai mult de 100 de caractere")]

        public string Descriere { get; set; }

        [Required(ErrorMessage = "Suma este obligatorie")]
        [Range(0, int.MaxValue)] //sa fie numar pozitiv
        public int Suma { get; set; }

        [Required(ErrorMessage = "Data expirarii este obligatorie")]
        [DataType(DataType.Date)]
        public DateTime DataExpirare { get; set; }

        [Required(ErrorMessage = "Statusul este obligatoriu")]
        public string Status { get; set; }

       
        public int? TypeId { get; set; }
        public virtual Type? Type { get; set; }
        [NotMapped]
        public IEnumerable<SelectListItem>? Tip { get; set; }
    }
}
