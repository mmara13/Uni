﻿using System.ComponentModel.DataAnnotations;

namespace ExamenDAW.Models
{
    public class Type
    {
        [Key]
        public int Id { get; set; }
        public string Tip { get; set; }
    }
}
