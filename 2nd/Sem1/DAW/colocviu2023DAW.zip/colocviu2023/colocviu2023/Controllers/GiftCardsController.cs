﻿using colocviu2023.Models;
using Humanizer;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.Rendering;
using Microsoft.EntityFrameworkCore;
using System.Text.RegularExpressions;

namespace colocviu2023.Controllers
{
    public class GiftCardsController : Controller
    {

        private readonly AppDbContext db;
        public GiftCardsController(AppDbContext context)
        {
            db = context;
        }

        public IActionResult Index()
        {

            var giftCards = db.GiftCards.Include("Brand").OrderBy(a => a.DataExp);
            ViewBag.GiftCards = giftCards;

            if (TempData.ContainsKey("message"))
            {
                ViewBag.Message = TempData["message"];
            }

            return View();
        }

        public IActionResult Index2()
        {
            var giftCards = db.GiftCards.Include("Brand").OrderBy(a => a.DataExp);

            var search = "";

            // MOTOR DE CAUTARE

            if (Convert.ToString(HttpContext.Request.Query["search"]) != null)
            {
                search = Convert.ToString(HttpContext.Request.Query["search"]).Trim(); // eliminam spatiile libere 

                // Cautare in articol (Title si Content)

                /*
                List<int> giftIds = db.GiftCards
                    .Where(gc => gc.Denumire.Contains(search)  && gc.Procent >= 30)
                    .Select(a => a.Id)
                    .ToList(); 

                */

                int searchInt;
                bool isNumeric = int.TryParse(search, out searchInt);
                
                List<int> giftIds = db.GiftCards
                    .Where(gc => gc.Denumire.Contains(search) || (isNumeric && gc.Procent == searchInt) && gc.Procent >= 30)
                    .OrderByDescending(gc => gc.DataExp.HasValue)
                    .ThenByDescending(gc => gc.DataExp)
                    .Select(a => a.Id)
                    .ToList();
                



                // Lista articolelor care contin cuvantul cautat
                // fie in articol -> Title si Content
                // fie in comentarii -> Content
                giftCards = db.GiftCards.Where(gc => giftIds.Contains(gc.Id))
                                      .Include("Brand")
                                      .OrderByDescending(a => a.Procent);

            }

            ViewBag.SearchString = search;

            // AFISARE PAGINATA

            // Alegem sa afisam 3 articole pe pagina
            int _perPage = 3;

            if (TempData.ContainsKey("message"))
            {
                ViewBag.message = TempData["message"].ToString();
            }

            int totalItems = giftCards.Count();


            // Se preia pagina curenta din View-ul asociat
            // Numarul paginii este valoarea parametrului page din ruta
            // /Articles/Index?page=valoare

            var currentPage = Convert.ToInt32(HttpContext.Request.Query["page"]);

            // Pentru prima pagina offsetul o sa fie zero
            // Pentru pagina 2 o sa fie 3 
            // Asadar offsetul este egal cu numarul de articole care au fost deja afisate pe paginile anterioare
            var offset = 0;

            // Se calculeaza offsetul in functie de numarul paginii la care suntem
            if (!currentPage.Equals(0))
            {
                offset = (currentPage - 1) * _perPage;
            }

            // Se preiau articolele corespunzatoare pentru fiecare pagina la care ne aflam 
            // in functie de offset
            var paginatedArticles = giftCards.Skip(offset).Take(_perPage);


            // Preluam numarul ultimei pagini

            ViewBag.lastPage = Math.Ceiling((float)totalItems / (float)_perPage);

            // Trimitem articolele cu ajutorul unui ViewBag catre View-ul corespunzator
            ViewBag.GiftCards = paginatedArticles;

            if (search != "")
            {
                ViewBag.PaginationBaseUrl = "/GiftCards/Index2/?search=" + search + "&page";
            }
            else
            {
                ViewBag.PaginationBaseUrl = "/GiftCards/Index2/?page";
            }

            return View();

        }
        public IActionResult Show(int id)
        {
            GiftCard GiftCard = db.GiftCards.Include("Brand")
                               .Where(gc => gc.Id == id)
                               .First();

            return View(GiftCard);
        }

        public IActionResult New()
        {
            GiftCard giftCard = new GiftCard();

            giftCard.brd = GetAllBrands();

            return View(giftCard);
        }

        // Se adauga articolul in baza de date
        [HttpPost]
        public IActionResult New(GiftCard giftCard)
        {
            giftCard.brd = GetAllBrands();
            if (giftCard.DataExp <= DateTime.Now)
            {
                ModelState.AddModelError("DataExp", "Data expirarii trebuie sa fie mai mare decat data curenta.");
            }

             if (ModelState.IsValid)
            {
                db.GiftCards.Add(giftCard);
                db.SaveChanges();
                TempData["message"] = "Cardul a fost adaugat";
                return RedirectToAction("Index");
            }
            else
            {
                return View(giftCard);
            }

        }

        public IActionResult Edit(int id)
        {

            GiftCard giftCard = db.GiftCards.Include("Brand")
                                        .Where(gc => gc.Id == id)
                                        .First();

            giftCard.brd = GetAllBrands();

            return View(giftCard);

        }

        // Se adauga articolul modificat in baza de date
        [HttpPost]
        public IActionResult Edit(int id, GiftCard requestCard)
        {
            GiftCard giftCard = db.GiftCards.Find(id);
            requestCard.brd = GetAllBrands();

            if (ModelState.IsValid)
            {
                giftCard.Denumire = requestCard.Denumire;
                giftCard.Descriere = requestCard.Descriere;
                giftCard.DataExp = requestCard.DataExp;
                giftCard.Procent = requestCard.Procent;
                TempData["message"] = "Cardul a fost modificat";
                db.SaveChanges();
                return RedirectToAction("Index");
            }
            else
            {
                return View(requestCard);
            }
        }


        public IEnumerable<SelectListItem> GetAllBrands()
        {
            // generam o lista de tipul SelectListItem fara elemente
            var selectList = new List<SelectListItem>();

            // extragem toate categoriile din baza de date
            var brands = from brd in db.Brands
                             select brd;

            // iteram prin categorii
            foreach (var brand in brands)
            {
                // adaugam in lista elementele necesare pentru dropdown
                // id-ul categoriei si denumirea acesteia
                selectList.Add(new SelectListItem
                {
                    Value = brand.Id.ToString(),
                    Text = brand.Nume.ToString()
                });
            }

            return selectList;
        }




    }
}
