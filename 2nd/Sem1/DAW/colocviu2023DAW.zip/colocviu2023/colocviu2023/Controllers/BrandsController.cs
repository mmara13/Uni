﻿using Microsoft.AspNetCore.Mvc;

namespace colocviu2023.Controllers
{
    public class BrandsController : Controller
    {
        public IActionResult Index()
        {
            return View();
        }
    }
}
