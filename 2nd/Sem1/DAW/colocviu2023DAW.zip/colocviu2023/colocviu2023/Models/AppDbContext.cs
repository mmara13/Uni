﻿using Microsoft.EntityFrameworkCore;

namespace colocviu2023.Models
{
    public class AppDbContext : DbContext
    {
        public AppDbContext(DbContextOptions<AppDbContext> options): base(options)
        {
        }

        public DbSet<GiftCard> GiftCards { get; set; }
        public DbSet<Brand> Brands { get; set; }
    }
}
