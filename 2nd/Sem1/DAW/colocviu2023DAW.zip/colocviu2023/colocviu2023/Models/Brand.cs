﻿using System.ComponentModel.DataAnnotations;

namespace colocviu2023.Models
{
    public class Brand
    {
        [Key]
        public int Id { get; set; }

        [Required(ErrorMessage = "Numele este obligatorie")]

        public string Nume { get; set; }

        public virtual ICollection<GiftCard>?  GiftCards { get; set; }
    }
}
