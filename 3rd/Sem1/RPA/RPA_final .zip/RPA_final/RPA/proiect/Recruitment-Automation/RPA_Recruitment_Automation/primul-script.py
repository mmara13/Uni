import pandas as pd
import os
import textract
import re
import nltk
from sklearn.feature_extraction.text import CountVectorizer
from sklearn.metrics.pairwise import cosine_similarity
from tabulate import tabulate
 
# Funcții pentru procesarea textului
def data_load(file):
    ''' Citește fișiere de diferite tipuri și returnează textul extras '''
    data = str(textract.process(file), 'UTF-8')
    return data
 
def clean_text(text):
    ''' Curăță caracterele speciale din text '''
    cleaned_data = re.sub(r'[^a-zA-Z0-9\s]', '', text)
    return cleaned_data
 
def nltk_tokenizer(text):
    ''' Tokenizează textul folosind NLTK '''
    nltk.download('punkt')
    from nltk import word_tokenize
    tokens = word_tokenize(text)
    return tokens
 
def nltk_pos_tag(token_list):
    ''' Aplică tag-uri POS folosind NLTK '''
    nltk.download('averaged_perceptron_tagger')
    from nltk import pos_tag
    return pos_tag(token_list)
 
def nltk_stopwords_removal(token_list):
    ''' Îndepărtează stopwords folosind NLTK '''
    nltk.download('stopwords')
    from nltk.corpus import stopwords
    stop_words = set(stopwords.words('english'))
    return [w for w in token_list if w not in stop_words]
 
def unique_tokens(token_list):
    ''' Elimina duplicatele din lista de tokenuri '''
    return list(set([token.lower() for token in token_list]))
 
def nltk_keywords(data):
    ''' Extrage cuvintele cheie folosind NLTK '''
    data = clean_text(data)
    tokens = nltk_tokenizer(data)
    pos_tagged_tokens = nltk_pos_tag(tokens)
    keywords = [t[0] for t in pos_tagged_tokens if t[1] in ['NNP', 'NN', 'JJ']]
    keywords = nltk_stopwords_removal(keywords)
    return unique_tokens(keywords)
 
# Funcții pentru manipularea fișierelor CSV
def get_position_from_email(email_body):
    ''' Extrage poziția din corpul emailului folosind regex '''
    match = re.search(r'"(.*?)"', email_body)
    if match:
        return match.group(1)
    return None
 
def extract_required_skills_and_qualifications(requirements):
    ''' Extrage secțiunile 'Required Skills and Qualifications' și 'Nice to Have' din cerințe '''
    start = requirements.find("Required Skills and Qualifications")
    end = requirements.find("How to Apply")
    if start != -1 and end != -1:
        return requirements[start:end].strip()
    return ""
 
# Funcția principală
def process_candidates():
    # Citirea fișierelor CSV
    candidates_path = "C:\\Users\\ancao\\Desktop\\Facultate an4 sem1\\RPA\\proiect\\Recruitment-Automation\\Candidates.csv"
    jobs_path = "C:\\Users\\ancao\\Desktop\\Facultate an4 sem1\\RPA\\proiect\\Recruitment-Automation\\RPA_Recruitment_Automation\\date_jobs.csv"
    result_path = "C:\\Users\\ancao\\Desktop\\Facultate an4 sem1\\RPA\\proiect\\Recruitment-Automation\\RPA_Recruitment_Automation\\ResultCandidates.csv"
    cvs_path = "C:\\Users\\ancao\\Desktop\\Facultate an4 sem1\\RPA\\proiect\\Recruitment-Automation\\CVs"
 
    candidates_df = pd.read_csv(candidates_path)
    jobs_df = pd.read_csv(jobs_path)
 
    # Inițializare lista pentru rezultate
    result_data = []
 
    for _, candidate in candidates_df.iterrows():
        email_body = candidate['EmailBody']
        position = get_position_from_email(email_body)
 
        if not position:
            continue
 
        # Găsirea cerințelor pentru jobul respectiv
        job_row = jobs_df[jobs_df['Position'] == position]
        if job_row.empty:
            continue
 
        requirements = job_row['Requirements'].values[0]
        required_skills = extract_required_skills_and_qualifications(requirements)
 
        # Extrage cuvintele cheie din CV-uri
        cvs_files = os.listdir(cvs_path)
        candidate_keywords = []
        for cv_file in cvs_files:
            cv_file_path = os.path.join(cvs_path, cv_file)
            if cv_file.endswith('.pdf'):
                cv_text = data_load(cv_file_path)
                candidate_keywords += nltk_keywords(cv_text)
 
        # Compararea cuvintelor cheie
        job_keywords = nltk_keywords(required_skills)
        common_keywords = set(candidate_keywords).intersection(set(job_keywords))
        match_percentage = (len(common_keywords) / len(job_keywords)) * 100 if job_keywords else 0
 
        # Calculul scorului
        match_percentage = round(match_percentage, 2)
 
        # Decizia de acceptare sau respingere
        decision = 'Accept' if match_percentage >= 70 else 'Reject'
 
        # Adăugarea rezultatului
        result_data.append([candidate['Email'], decision, match_percentage])
 
    # Scrierea rezultatelor în fișierul CSV
    result_df = pd.DataFrame(result_data, columns=['Email', 'Accept/Reject', 'Match Percentage'])
    result_df.to_csv(result_path, index=False)
 
    print(f"Rezultatele au fost salvate în: {result_path}")
 
# Apelarea funcției principale
if __name__ == "__main__":
    process_candidates()
 