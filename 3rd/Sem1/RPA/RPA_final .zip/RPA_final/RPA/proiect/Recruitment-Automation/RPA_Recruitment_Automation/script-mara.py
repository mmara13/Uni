import pandas as pd
import re
import nltk
from sklearn.feature_extraction.text import CountVectorizer
from sklearn.metrics.pairwise import cosine_similarity
import spacy
from nltk.corpus import stopwords
nltk.download('punkt')
nltk.download('punkt_tab')
nltk.download('averaged_perceptron_tagger')
nltk.download('averaged_perceptron_tagger_eng')
nltk.download('stopwords')
nlp = spacy.load('en_core_web_sm')
 
def extract_position_from_email(email_body):
    """Extract position from quotes in email body"""
    if not isinstance(email_body, str):  # Check if email_body is a string
        return None
    match = re.search(r'"([^"]*)"', email_body)
    if match:
        return match.group(1)
    return None

 
def extract_requirements(requirements_text):
    """Extract required skills and nice to have sections"""
    try:
        # Find start of required skills
        start_idx = requirements_text.index("Required Skills and Qualifications")
        # Find end (start of "How to Apply")
        end_idx = requirements_text.index("How to Apply")
        # Extract relevant text
        return requirements_text[start_idx:end_idx].strip()
    except ValueError:
        return ""
 
def clean_text(text):
    """Clean non-ASCII special characters from text"""
    cleaned = re.sub(r'[^a-zA-Z0-9\s\/]', '', str(text))
    cleaned = cleaned.replace('/', ' ')
    return cleaned
 
def get_keywords(text):
    """Extract keywords using both NLTK and spaCy"""
    # Clean text
    text = clean_text(text)
 
    # NLTK processing
    tokens = nltk.word_tokenize(text)
    pos_tagged = nltk.pos_tag(tokens)
 
    # Filter for nouns, verbs, and adjectives
    keywords = [word for word, tag in pos_tagged if tag in ['NNP', 'NN', 'VBP', 'JJ']]
 
    # Remove stopwords
    stop_words = set(stopwords.words('english'))
    keywords = [w.lower() for w in keywords if w.lower() not in stop_words]
 
    # Remove duplicates
    keywords = list(set(keywords))
 
    return keywords
 
def calculate_match_scores(cv_text, requirements_text):
    """Calculate both keyword matching and cosine similarity scores"""
    # Get keywords
    cv_keywords = get_keywords(cv_text)
    req_keywords = get_keywords(requirements_text)
 
    # Print keywords for debugging
    print("CV Keywords:", cv_keywords)
    print("Requirements Keywords:", req_keywords)
 
    # Calculate keyword match percentage
    matching_keywords = [w for w in req_keywords if w in cv_keywords]
    print("Matching Keywords:", matching_keywords)
    
    keyword_match_percent = (len(matching_keywords) / len(req_keywords)) * 100 if req_keywords else 0
 
    # Calculate cosine similarity
    vectorizer = CountVectorizer()
    try:
        count_matrix = vectorizer.fit_transform([requirements_text, cv_text])
        cosine_score = cosine_similarity(count_matrix)[0][1] * 100
    except:
        cosine_score = 0
 
    return round(keyword_match_percent, 2), round(cosine_score, 2)
 
def evaluate_candidate(keyword_score, cosine_score, threshold_keyword=15, threshold_cosine=20):
    """Determine if candidate should be accepted based on scores"""
    # Accept if either score is above threshold
    if keyword_score >= threshold_keyword or cosine_score >= threshold_cosine:
        return "Accepted"
    return "Rejected"
 
def main():
    # Read input files
    candidates_df = pd.read_csv(r"C:\Users\ancao\Desktop\Facultate an4 sem1\RPA\proiect\Recruitment-Automation\Candidates.csv")
    jobs_df = pd.read_csv(r"C:\Users\ancao\Desktop\Facultate an4 sem1\RPA\proiect\Recruitment-Automation\RPA_Recruitment_Automation\date_jobs.csv")
 
    # Initialize results
    results = []
 
    # Process each candidate
    for _, candidate in candidates_df.iterrows():
        print("\n" + "="*50)
        print(f"Processing candidate: {candidate['emailAddress']}")
        
        # Extract position from email body
        position = extract_position_from_email(candidate['EmailBody'])
        print(f"Position extracted from email: {position}")
        
        if not position:
            print("No position found in email body - REJECTED")
            results.append({'Email': candidate['emailAddress'], 'Accept/Reject': 'Rejected'})
            continue
 
        # Find matching job requirements
        matching_job = jobs_df[jobs_df['Position'] == position]
        if matching_job.empty:
            print(f"No matching job found for position: {position} - REJECTED")
            results.append({'Email': candidate['emailAddress'], 'Accept/Reject': 'Rejected'})
            continue
 
        # Extract requirements
        requirements = extract_requirements(matching_job.iloc[0]['Requirements'])
        print("\nExtracted Requirements:")
        print(requirements[:200] + "...") # Print first 200 chars of requirements
 
        # Calculate match scores
        keyword_score, cosine_score = calculate_match_scores(candidate['CV'], requirements)
        print(f"\nScores:")
        print(f"Keyword match score: {keyword_score}%")
        print(f"Cosine similarity score: {cosine_score}%")
 
        # Evaluate candidate
        decision = evaluate_candidate(keyword_score, cosine_score)
        print(f"\nFinal decision: {decision}")
 
        # Store result
        results.append({
            'Email': candidate['emailAddress'],
            'Accept/Reject': decision
        })
 
    # Save results
    results_df = pd.DataFrame(results)
    results_df.to_csv(r"C:\Users\ancao\Desktop\Facultate an4 sem1\RPA\proiect\Recruitment-Automation\RPA_Recruitment_Automation\ResultCandidates.csv", index=False)
 
    print("\nProcessing complete. Results saved to ResultCandidates.csv")
 
if __name__ == "__main__":
    main()