﻿#include <windows.h>
#include <stdlib.h>
#include <stdio.h>
#include <math.h>
#include <iostream>
#include <GL/glew.h>
#include <GL/freeglut.h>
#include <GLFW/glfw3.h>
#include "loadShaders.h"
#include "glm/glm.hpp"
#include "glm/gtc/matrix_transform.hpp"
#include "glm/gtx/transform.hpp"
#include "glm/gtc/type_ptr.hpp"
#include "SOIL.h"
#include <vector>
using namespace std;
GLuint
VaoId1, VaoId2,
VboId1, VboId2,
EboId1, EboId2,
ColorBufferId,
ProgramIdv,
ProgramIdf,
viewLocation,
projLocation,
codColLocation,    
myMatrixLocation,
matrUmbraLocation,
depthLocation,
codCol;
GLuint VaoIdRing, VboIdRing, EboIdRing;
GLint objectColorLoc, lightColorLoc, lightPosLoc, viewPosLoc;
GLuint sunTexture, galaxyTexture;
GLuint backgroundVAO, backgroundVBO;
GLint isSunObjectLocation;

string numetextura;
float const PI = 3.141592f;
float const U_MIN = -PI / 2, U_MAX = PI / 2, V_MIN = 0, V_MAX = 2 * PI;
int const NR_PARR = 131, NR_MERID = 132;
float step_u = (U_MAX - U_MIN) / NR_PARR, step_v = (V_MAX - V_MIN) / NR_MERID;
float radius = 50;
int index, index_aux;
// variabile pentru matricea de vizualizare
float Obsx = 100.0, Obsy = -1500.0, Obsz = 200;
float Refx = 0.0f, Refy = 1000.0f, Refz = 0.0f;
float Vx = 0.0, Vy = 0.0, Vz = 1.0;
// variabile pentru matricea de proiectie
float width = 800, height = 600, znear = 0.1, fov = 45;
// matrice utilizate
glm::mat4 view, projection;
glm::mat4 myMatrix, matrTrans, matrScale, matrTransRotation;
// sursa de lumina
float xL = 0.0f, yL = 1000.0f, zL =0.0f;
// matricea umbrei
float matrUmbra[4][4];
float angleMercur = 0.0f, angleVenus = 0.0f, anglePamant = 0.0f, angleMarte = 0.0f, angleJupiter = 0.0f, angleSaturn = 0.0f, angleUranus = 0.0f, angleNeptun = 0.0f;

void processNormalKeys(unsigned char key, int x, int y)
{
	switch (key) {
	case 'l':
		Vx -= 0.1;
		break;
	case 'r':
		Vx += 0.1;
		break;
	case '+':
		Obsy += 10;
		break;
	case '-':
		Obsy -= 10;
		break;
	}
	if (key == 27)
		exit(0);
}
void processSpecialKeys(int key, int xx, int yy)
{
	switch (key) {
	case GLUT_KEY_LEFT:
		Obsx -= 20;
		break;
	case GLUT_KEY_RIGHT:
		Obsx += 20;
		break;
	case GLUT_KEY_UP:
		Obsz += 20;
		break;
	case GLUT_KEY_DOWN:
		Obsz -= 20;
		break;
	}
}

void CreateVBO1(void)
{

	GLfloat vertices[] = {
		//pozitii       //coordonate texuri
		-1.0f,  1.0f, 0.0f,  0.0f, 1.0f,  //sus stanga
		-1.0f, -1.0f, 0.0f,  0.0f, 0.0f,  //jos stanga
		 1.0f, -1.0f, 0.0f,  1.0f, 0.0f,  //jos dreapta
		 1.0f,  1.0f, 0.0f,  1.0f, 1.0f   //sus dreapta
	};

	GLuint indices[] = {
		0, 1, 2,
		0, 2, 3
	};

	GLuint VAO, VBO, EBO;
	glGenVertexArrays(1, &VAO);
	glGenBuffers(1, &VBO);
	glGenBuffers(1, &EBO);

	glBindVertexArray(VAO);

	//legam si setam vertex data
	glBindBuffer(GL_ARRAY_BUFFER, VBO);
	glBufferData(GL_ARRAY_BUFFER, sizeof(vertices), vertices, GL_STATIC_DRAW);

	//legam si setam index data
	glBindBuffer(GL_ELEMENT_ARRAY_BUFFER, EBO);
	glBufferData(GL_ELEMENT_ARRAY_BUFFER, sizeof(indices), indices, GL_STATIC_DRAW);

	//definim attrb vertex pt pozitii
	glVertexAttribPointer(0, 3, GL_FLOAT, GL_FALSE, 5 * sizeof(GLfloat), (void*)0);
	glEnableVertexAttribArray(0);

	//definim vertex attrib pt coord de texturi
	glVertexAttribPointer(1, 2, GL_FLOAT, GL_FALSE, 5 * sizeof(GLfloat), (void*)(3 * sizeof(GLfloat)));
	glEnableVertexAttribArray(1);

	//unbind VAO
	glBindVertexArray(0);


	glm::vec4 Vertices1[(NR_PARR + 1) * NR_MERID];
	GLushort Indices1[2 * (NR_PARR + 1) * NR_MERID + 4 * (NR_PARR + 1) * NR_MERID];
	for (int merid = 0; merid < NR_MERID; merid++)
	{
		for (int parr = 0; parr < NR_PARR + 1; parr++)
		{
			float u = U_MIN + parr * step_u;
			float v = V_MIN + merid * step_v;
			float x_vf = radius * cosf(u) * cosf(v);
			float y_vf = radius * cosf(u) * sinf(v);
			float z_vf = radius * sinf(u);
			index = merid * (NR_PARR + 1) + parr;
			Vertices1[index] = glm::vec4(x_vf, y_vf, z_vf, 1.0);
			Indices1[index] = index;
			index_aux = parr * (NR_MERID)+merid;
			Indices1[(NR_PARR + 1) * NR_MERID + index_aux] = index;
			if ((parr + 1) % (NR_PARR + 1) != 0)
			{
				int AUX = 2 * (NR_PARR + 1) * NR_MERID;
				int index1 = index;
				int index2 = index + (NR_PARR + 1);
				int index3 = index2 + 1;
				int index4 = index + 1;
				if (merid == NR_MERID - 1)
				{
					index2 = index2 % (NR_PARR + 1);
					index3 = index3 % (NR_PARR + 1);
				}
				Indices1[AUX + 4 * index] = index1;
				Indices1[AUX + 4 * index + 1] = index2;
				Indices1[AUX + 4 * index + 2] = index3;
				Indices1[AUX + 4 * index + 3] = index4;
			}
		}
	}
	glGenVertexArrays(1, &VaoId1);
	glGenBuffers(1, &VboId1);
	glGenBuffers(1, &EboId1);
	glBindVertexArray(VaoId1);
	glBindBuffer(GL_ARRAY_BUFFER, VboId1);
	glBufferData(GL_ARRAY_BUFFER, sizeof(Vertices1), Vertices1, GL_STATIC_DRAW);
	glBindBuffer(GL_ELEMENT_ARRAY_BUFFER, EboId1);
	glBufferData(GL_ELEMENT_ARRAY_BUFFER, sizeof(Indices1), Indices1, GL_STATIC_DRAW);
	glEnableVertexAttribArray(0);
	glVertexAttribPointer(0, 3, GL_FLOAT, GL_FALSE, 6 * sizeof(GLfloat), (GLvoid*)0);
	glEnableVertexAttribArray(1);
	glVertexAttribPointer(1, 3, GL_FLOAT, GL_FALSE, 6 * sizeof(GLfloat), (GLvoid*)(3 * sizeof(GLfloat)));
	glEnableVertexAttribArray(2);
	glVertexAttribPointer(2, 2, GL_FLOAT, GL_FALSE, 9 * sizeof(GLfloat), (GLvoid*)(3 * sizeof(GLfloat)));

	glGenVertexArrays(1, &VaoIdRing);
	glGenBuffers(1, &VboIdRing);
	glBindVertexArray(VaoIdRing);
	glBindBuffer(GL_ARRAY_BUFFER, VboIdRing);

	//definim vertices si indices pt rings

	vector<GLfloat> VerticesRing;
	vector<GLushort> IndicesRing;
	float ringRadius = 55.0f;

	for (int i = 0; i <= NR_MERID; i++) {
		float angle = static_cast<float>(i) / NR_MERID * (2.0f * PI);
		float x = ringRadius * cosf(angle);
		float y = ringRadius * sinf(angle);
		float z = 0.0f; //coordonata z pentru ring

		//vertex coordonate
		VerticesRing.push_back(x);
		VerticesRing.push_back(y);
		VerticesRing.push_back(z);

		//adaugare index
		IndicesRing.push_back(i);
	}

	glBufferData(GL_ARRAY_BUFFER, VerticesRing.size() * sizeof(GLfloat), VerticesRing.data(), GL_STATIC_DRAW);
	
	glBufferData(GL_ELEMENT_ARRAY_BUFFER, IndicesRing.size() * sizeof(GLushort), IndicesRing.data(), GL_STATIC_DRAW);

	glEnableVertexAttribArray(0);
	glVertexAttribPointer(0, 3, GL_FLOAT, GL_FALSE, 3 * sizeof(GLfloat), (GLvoid*)0);


}
void DestroyVBO(void)
{
	glDisableVertexAttribArray(1);
	glDisableVertexAttribArray(0);
	glBindBuffer(GL_ARRAY_BUFFER, 0);
	glDeleteBuffers(1, &VboId1);
	glDeleteBuffers(1, &EboId1);
	glBindVertexArray(0);
	glDeleteVertexArrays(1, &VaoId1);
	glDeleteBuffers(1, &VboIdRing);
	glBindVertexArray(0);
	glDeleteVertexArrays(1, &VaoIdRing);
}



void LoadTexture(const char* photoPath, GLuint &texture)
{
	glGenTextures(1, &texture);
	glBindTexture(GL_TEXTURE_2D, texture);

	glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_S, GL_CLAMP);
	glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_T, GL_REPEAT);

	glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MIN_FILTER, GL_NEAREST);
	glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MAG_FILTER, GL_NEAREST);

	int width, height;
	unsigned char* image = SOIL_load_image(photoPath, &width, &height, 0, SOIL_LOAD_RGB);
	glTexImage2D(GL_TEXTURE_2D, 0, GL_RGB, width, height, 0, GL_RGB, GL_UNSIGNED_BYTE, image);
	glGenerateMipmap(GL_TEXTURE_2D);

	SOIL_free_image_data(image);
	glBindTexture(GL_TEXTURE_2D, 0);
}

void CreateShadersFragment(void)
{
	ProgramIdf = LoadShaders("shaderPlanete.vert", "shaderPlanete.frag");
	glUseProgram(ProgramIdf);
}
void DestroyShaders(void)
{
	glDeleteProgram(ProgramIdf);
}

void Initialize(void) {
	

	CreateVBO1();
	CreateShadersFragment();

	objectColorLoc = glGetUniformLocation(ProgramIdf, "objectColor");
	lightColorLoc = glGetUniformLocation(ProgramIdf, "lightColor");
	lightPosLoc = glGetUniformLocation(ProgramIdf, "lightPos");
	viewPosLoc = glGetUniformLocation(ProgramIdf, "viewPos");
	viewLocation = glGetUniformLocation(ProgramIdf, "view");
	projLocation = glGetUniformLocation(ProgramIdf, "projection");
	myMatrixLocation = glGetUniformLocation(ProgramIdf, "myMatrix");
	matrUmbraLocation = glGetUniformLocation(ProgramIdf, "matrUmbra");
	codColLocation = glGetUniformLocation(ProgramIdf, "codCol");
	isSunObjectLocation = glGetUniformLocation(ProgramIdf, "isSunObject");
	

	glUseProgram(ProgramIdf);
	glUniform1i(glGetUniformLocation(ProgramIdf, "galaxyTexture"), 0);
	glUniform1i(glGetUniformLocation(ProgramIdf, "sunTexture"), 1);

	LoadTexture("spatiu.jpg", galaxyTexture);
	LoadTexture("soare.jpg", sunTexture);



	//cream forma ecranului pt background
	float quadVertices[] = {
		//pozitii        // normale       //coordonate texturi
		-1.0f,  1.0f, 0.0f, 0.0f, 0.0f, 1.0f, 0.0f, 1.0f,
		-1.0f, -1.0f, 0.0f, 0.0f, 0.0f, 1.0f, 0.0f, 0.0f,
		 1.0f, -1.0f, 0.0f, 0.0f, 0.0f, 1.0f, 1.0f, 0.0f,

		-1.0f,  1.0f, 0.0f, 0.0f, 0.0f, 1.0f, 0.0f, 1.0f,
		 1.0f, -1.0f, 0.0f, 0.0f, 0.0f, 1.0f, 1.0f, 0.0f,
		 1.0f,  1.0f, 0.0f, 0.0f, 0.0f, 1.0f, 1.0f, 1.0f
	};

	glGenVertexArrays(1, &backgroundVAO);
	glGenBuffers(1, &backgroundVBO);
	glBindVertexArray(backgroundVAO);
	glBindBuffer(GL_ARRAY_BUFFER, backgroundVBO);
	glBufferData(GL_ARRAY_BUFFER, sizeof(quadVertices), &quadVertices, GL_STATIC_DRAW);

	//attrib poz
	glVertexAttribPointer(0, 3, GL_FLOAT, GL_FALSE, 8 * sizeof(float), (void*)0);
	glEnableVertexAttribArray(0);
	//attrib normala
	glVertexAttribPointer(1, 3, GL_FLOAT, GL_FALSE, 8 * sizeof(float), (void*)(3 * sizeof(float)));
	glEnableVertexAttribArray(1);
	//attrib tetura
	glVertexAttribPointer(2, 2, GL_FLOAT, GL_FALSE, 8 * sizeof(float), (void*)(6 * sizeof(float)));
	glEnableVertexAttribArray(2);
}
void DrawPlanet(glm::mat4 myMatrix, int codCol = 0)
{
	glBindVertexArray(VaoId1);
	glUniform1i(codColLocation, codCol);
	glUniformMatrix4fv(myMatrixLocation, 1, GL_FALSE, &myMatrix[0][0]);
	for (int patr = 0; patr < (NR_PARR + 1) * NR_MERID; patr++)
	{
		if ((patr + 1) % (NR_PARR + 1) != 0)
			glDrawElements(GL_TRIANGLES, 4, GL_UNSIGNED_SHORT, (GLvoid*)((2 * (NR_PARR + 1)
				* (NR_MERID)+4 * patr) * sizeof(GLushort)));
	}

}

void drawEllipse(float centerX, float centerY, float a, float b) {

	glBegin(GL_LINE_STRIP);
	for (int i = 0; i <= 360; i++) {
		float angle = i * PI / 180.0;
		float x = centerX + a * cos(angle);
		float y = centerY + b * sin(angle);
		glVertex2f(x, y);
	}
	glEnd();

}


void DrawShadow(glm::mat4 myMatrix)
{
	
	glBindVertexArray(VaoId1);
	codCol = 1;
	glUniform1i(codColLocation, codCol);
	glUniformMatrix4fv(myMatrixLocation, 1, GL_FALSE, &myMatrix[0][0]);
	for (int patr = 0; patr < (NR_PARR + 1) * NR_MERID; patr++)
	{
		if ((patr + 1) % (NR_PARR + 1) != 0)
			glDrawElements(GL_TRIANGLES, 4, GL_UNSIGNED_SHORT, (GLvoid*)((2 * (NR_PARR + 1)
				* (NR_MERID)+4 * patr) * sizeof(GLushort)));
	}
}
void RenderFunction(void)
{

	glClear(GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT);
	glDisable(GL_DEPTH_TEST);  //dezactivam depth testing pt background

	//desenare background
	glUseProgram(ProgramIdf);
	glBindVertexArray(backgroundVAO);

	//uniforme pt background
	glUniform1i(codColLocation, 2);  
	glUniform3f(objectColorLoc, 1.0f, 1.0f, 1.0f);
	glUniform3f(lightColorLoc, 1.0f, 1.0f, 1.0f);

	//matricile pt background
	glm::mat4 identityMatrix = glm::mat4(1.0f);
	glUniformMatrix4fv(myMatrixLocation, 1, GL_FALSE, glm::value_ptr(identityMatrix));
	glUniformMatrix4fv(viewLocation, 1, GL_FALSE, glm::value_ptr(identityMatrix));
	glUniformMatrix4fv(projLocation, 1, GL_FALSE, glm::value_ptr(identityMatrix));

	//bind background texture
	glActiveTexture(GL_TEXTURE0);
	glBindTexture(GL_TEXTURE_2D, galaxyTexture);
	glDrawArrays(GL_TRIANGLES, 0, 6);

	//punem inapoi depth testing pt 3D objects
	glEnable(GL_DEPTH_TEST);

	glEnable(GL_DEPTH_TEST);

	
	//camera si projection setup
	glm::vec3 Obs = glm::vec3(Obsx, Obsy, Obsz);
	glm::vec3 PctRef = glm::vec3(Refx, Refy, Refz);
	glm::vec3 Vert = glm::vec3(Vx, Vy, Vz);
	view = glm::lookAt(Obs, PctRef, Vert);
	glUniformMatrix4fv(viewLocation, 1, GL_FALSE, &view[0][0]);
	projection = glm::infinitePerspective(fov, GLfloat(width) / GLfloat(height), znear);
	glUniformMatrix4fv(projLocation, 1, GL_FALSE, &projection[0][0]);

	// matrice umbra
	glUniformMatrix4fv(matrUmbraLocation, 1, GL_FALSE, &matrUmbra[0][0]);

	glUseProgram(ProgramIdf);


	GLint modelLocation = glGetUniformLocation(ProgramIdf, "model");

	//legam VAO
	glBindVertexArray(VboId1);

	//desenare background cu texture
	glm::mat4 model = glm::mat4(1.0f);
	glUniformMatrix4fv(modelLocation, 1, GL_FALSE, &model[0][0]);

	glDrawElements(GL_TRIANGLES, 6, GL_UNSIGNED_INT, 0);

	//unbind the VAO
	glBindVertexArray(0);
	
	// SOARELE

	//setam isSunObject la true ianinte sa desenam soarele
	glUniform1i(isSunObjectLocation, GL_TRUE);  //setam uniforma true


	matrTrans = glm::translate(glm::mat4(1.0f), glm::vec3(0.0f, 1000.0f, 0.0f));
	matrScale = glm::scale(glm::mat4(1.0f), glm::vec3(3.f, 3.f, 3.f));
	glm::vec3 lightPosition = glm::vec3(0.0f, 1000.0f, 0.0f); //coordonatele Soarelui
	glUniform3f(lightPosLoc, lightPosition.x, lightPosition.y, lightPosition.z);
	glUniform3f(objectColorLoc, 0.0f, 0.0f, 0.0f);
	glUniform3f(lightColorLoc, 1.0f, 1.0f, 1.0f);
	glUniform3f(viewPosLoc, Obsx, Obsy, Obsz);
	myMatrix = matrTrans * matrScale;\

	//legam textura soarelui de unit 1
	glActiveTexture(GL_TEXTURE1);
	glBindTexture(GL_TEXTURE_2D, sunTexture);

	DrawPlanet(myMatrix, 2);

	//dupa desenare soare set isSunObject la false pt alte obiecte
	glUniform1i(isSunObjectLocation, GL_FALSE);  //setam uniforma la false


	glColor3f(1.0f, 1.0f, 1.0f);
	drawEllipse(0, 0, 200, 200);
	drawEllipse(0, 0, 260, 260);
	drawEllipse(0, 0, 325, 325);
	drawEllipse(0, 0, 400, 400);
	drawEllipse(0, 0, 465, 465);
	drawEllipse(0, 0, 530, 530);
	drawEllipse(0, 0, 595, 595);
	drawEllipse(0, 0, 660, 660);

	// MERCUR
	angleMercur += 0.04f;

	matrTrans = glm::translate(glm::mat4(1.0f), glm::vec3( 600.0f * cos(angleMercur), 1000.f + 600.0f * sin(angleMercur), 0.f));
	matrScale = glm::scale(glm::mat4(1.0f), glm::vec3(0.5f, 0.5f, 0.5f));
	glUniform3f(objectColorLoc, 0.45f, 0.57f, 0.7f);
	glUniform3f(lightColorLoc, 1.0f, 1.0f, 1.0f);
	glUniform3f(lightPosLoc, 0.f, 1000.f, 0.f);
	glUniform3f(viewPosLoc, Obsx, Obsy, Obsz);
	myMatrix = matrTrans * matrScale;


	DrawPlanet(myMatrix);
	//DrawShadow(myMatrix);


	// VENUS
	angleVenus += 0.035f;

	matrTrans = glm::translate(glm::mat4(1.0f), glm::vec3(775.0f * cos(angleVenus), 1000.f + 775.0f * sin(angleVenus), 0.f));
	matrScale = glm::scale(glm::mat4(1.0f), glm::vec3(0.6f, 0.6f, 0.6f));
	glUniform3f(objectColorLoc, 0.8f, 0.33f, 0.0f);
	glUniform3f(lightColorLoc, 1.0f, 1.0f, 1.0f);
	glUniform3f(lightPosLoc, 0.f, 1000.f, 0.f);
	glUniform3f(viewPosLoc, Obsx, Obsy, Obsz);
	myMatrix = matrTrans * matrScale;

	DrawPlanet(myMatrix);

	//DrawShadow(myMatrix);
	// PAMANT (Earth)
	anglePamant += 0.03f;
	matrTrans = glm::translate(glm::mat4(1.0f), glm::vec3(975.0f * cos(anglePamant), 1000.f + 975.0f * sin(anglePamant), 0.f));
	matrScale = glm::scale(glm::mat4(1.0f), glm::vec3(0.7f, 0.7f, 0.7f));
	glUniform3f(objectColorLoc, 0.0f, 0.0f, 0.63f);
	glUniform3f(lightColorLoc, 1.0f, 1.0f, 1.0f);
	glUniform3f(lightPosLoc, 0.f, 1000.f, 0.f);
	glUniform3f(viewPosLoc, Obsx, Obsy, Obsz);
	myMatrix = matrTrans * matrScale;
	DrawPlanet(myMatrix);

	// LUNA (Moon)
	static float angleLuna = 0.0f;
	angleLuna += 0.08f;  // luna se invarte mai rpd ca pamantu

	//calculam pozitia curenta a pamantului
	float earthX = 975.0f * cos(anglePamant);
	float earthY = 1000.f + 975.0f * sin(anglePamant);

	//pozitia lunii: se roteste in jurul poz curente a pamantului
	float moonOrbitRadius = 75.0f;  //distanta de la Earth la Moon
	matrTrans = glm::translate(glm::mat4(1.0f),
		glm::vec3(earthX + moonOrbitRadius * cos(angleLuna),
			earthY + moonOrbitRadius * sin(angleLuna),
			0.f));
	matrScale = glm::scale(glm::mat4(1.0f), glm::vec3(0.3f, 0.3f, 0.3f));
	glUniform3f(objectColorLoc, 0.9f, 0.9f, 0.9f);
	glUniform3f(lightColorLoc, 1.0f, 1.0f, 1.0f);
	glUniform3f(lightPosLoc, 0.f, 1000.f, 0.f);
	glUniform3f(viewPosLoc, Obsx, Obsy, Obsz);
	myMatrix = matrTrans * matrScale;
	DrawPlanet(myMatrix);
	

	// MARTE

	angleMarte += 0.025;
	matrTrans = glm::translate(glm::mat4(1.0f), glm::vec3(1200.0f * cos(angleMarte), 1000.f + 1200.0f * sin(angleMarte), 0.f));
	matrScale = glm::scale(glm::mat4(1.0f), glm::vec3(0.5f, 0.5f, 0.5f));
	glUniform3f(objectColorLoc, 0.64f, 0.16f, 0.16f);
	glUniform3f(lightColorLoc, 1.0f, 1.0f, 1.0f);
	glUniform3f(lightPosLoc, 0.f, 1000.f, 0.f);
	glUniform3f(viewPosLoc, Obsx, Obsy, Obsz);
	myMatrix = matrTrans * matrScale;
	DrawPlanet(myMatrix);

	//Jupiter

	angleJupiter += 0.02;
	matrTrans = glm::translate(glm::mat4(1.0f), glm::vec3(1400.0f * cos(angleJupiter), 1000.f + 1400.0f * sin(angleJupiter), 0.f));
	matrScale = glm::scale(glm::mat4(1.0f), glm::vec3(1.0f, 1.0f, 1.0f));
	glUniform3f(objectColorLoc, 0.64f, 0.16f, 0.16f);
	glUniform3f(lightColorLoc, 1.0f, 1.0f, 1.0f);
	glUniform3f(lightPosLoc, 0.f, 1000.f, 150.f);
	glUniform3f(viewPosLoc, Obsx, Obsy, Obsz);
	myMatrix = matrTrans * matrScale;
	DrawPlanet(myMatrix);

	//Saturn

	angleSaturn += 0.015;
	matrTrans = glm::translate(glm::mat4(1.0f), glm::vec3(1600.0f * cos(angleSaturn), 1000.f + 1600.0f * sin(angleSaturn), 0.f));
	matrScale = glm::scale(glm::mat4(1.0f), glm::vec3(0.85f, 0.85f, 0.85f));
	glUniform3f(objectColorLoc, 0.7f, 0.5f, 0.0f);
	glUniform3f(lightColorLoc, 1.0f, 1.0f, 1.0f);
	glUniform3f(lightPosLoc, 0.f, 1000.f, 0.f);
	glUniform3f(viewPosLoc, Obsx, Obsy, Obsz);
	myMatrix = matrTrans * matrScale;
	DrawPlanet(myMatrix);

	glColor3f(1.0f, 1.0f, 1.0f);
	drawEllipse(0, 0, 100, 100);
	drawEllipse(0, 0, 90, 90);
	drawEllipse(0, 0, 80, 80);
	drawEllipse(0, 0, 70, 70);
	drawEllipse(0, 0, 60, 60);
	
	//Uranus

	angleUranus += 0.01;
	matrTrans = glm::translate(glm::mat4(1.0f), glm::vec3(1800.0f * cos(angleUranus), 1000.f + 1800.0f * sin(angleUranus), 0.f));
	matrScale = glm::scale(glm::mat4(1.0f), glm::vec3(0.7f, 0.7f, 0.7f));
	glUniform3f(objectColorLoc, 0.3f, 1.0f, 1.0f);
	glUniform3f(lightColorLoc, 1.0f, 1.0f, 1.0f);
	glUniform3f(lightPosLoc, 0.f, 1000.f, 0.f);
	glUniform3f(viewPosLoc, Obsx, Obsy, Obsz);
	myMatrix = matrTrans * matrScale;
	DrawPlanet(myMatrix);

	glColor3f(1.0f, 1.0f, 1.0f);
	drawEllipse(0, 0, 70, 70);
	drawEllipse(0, 0, 60, 60);

	//Neptun

	angleNeptun += 0.005;
	matrTrans = glm::translate(glm::mat4(1.0f), glm::vec3(2000.0f * cos(angleNeptun), 1000.f + 2000.0f * sin(angleNeptun), 0.f));
	matrScale = glm::scale(glm::mat4(1.0f), glm::vec3(0.7f, 0.7f, 0.7f));
	glUniform3f(objectColorLoc, 0.0f, 0.5f, 1.0f);
	glUniform3f(lightColorLoc, 1.0f, 1.0f, 1.0f);
	glUniform3f(lightPosLoc, 0.f, 1000.f, 0.f);
	glUniform3f(viewPosLoc, Obsx, Obsy, Obsz);
	myMatrix = matrTrans * matrScale;
	DrawPlanet(myMatrix);

	glutSwapBuffers();
	glFlush();
	glutPostRedisplay();
}
void Cleanup(void)
{
	DestroyShaders();
	DestroyVBO();
}
int main(int argc, char* argv[])
{
	glutInit(&argc, argv);
	glutInitDisplayMode(GLUT_RGB | GLUT_DEPTH | GLUT_DOUBLE);
	glutInitWindowPosition(100, 10);
	glutInitWindowSize(1000, 750);
	glutCreateWindow("Sistemul Solar");
	glewInit();
	Initialize();
	glutIdleFunc(RenderFunction);
	glutDisplayFunc(RenderFunction);
	glutKeyboardFunc(processNormalKeys);
	glutSpecialFunc(processSpecialKeys);
	glutAttachMenu(GLUT_RIGHT_BUTTON);
	glutCloseFunc(Cleanup);
	glutMainLoop();
}