//pt prima cerinta modificam scrisul sa fie bold pt toate butoanele

document.addEventListener('DOMContentLoaded', function() { //am pus codul in functie pentru ca modificarile
    //trb facute abia dupa ce pagina se incarca, ptc altfel nu apareau
    //luam toate butoanele cu clasa button(tot in afara de cel negru) folosind querySelectorAll
    const buttons = document.querySelectorAll('.button');
  
    //pt fiecare buton din array-ul obtinut schimbam in scris bold
    buttons.forEach(button => {
      button.style.fontWeight = 'bold';
    });

    //adaugare elem folosind js
    const button = document.createElement('button'); //creem butonul visit audi media center folosind js, apoi il stergem pe cel vechi
    button.textContent = 'Visit Audi MediaCenter'; //afisam acelasi lucru ca pe butonul vechi
    button.style.backgroundColor = 'black'; //fundal negru
    button.style.color = 'white'; //scris alb
    button.style.padding = '20px 86px'; //marimea butonului ca sa fie exact la fel cu cel anterior
    button.style.fontSize = '15px'; //am luat datele din audi.css ca sa arate la fel

    const parentDiv = document.getElementById('blackb'); //luam id-ul divului in care vrem sa il punem
    parentDiv.appendChild(button); //il adaugam ca fiu al divului

    button.addEventListener('click', function() {
        window.open('https://www.audi-mediacenter.com/en', '_blank');//adaugam event ca sa ne duca la pag dorita, dar intr-una noua
        }
    );


    //stergerea butonului vechi 
    const oldButton = document.getElementsByClassName('blackbutton'); //luam clasa butonului vechi(doar el are clasa respectiva ptc e sg buton negru)
    oldButton[0].remove(); //stergem butonul vechi


    //eveniment de click + schimbare culoare pt restul butoanelor
    const buttons_rest= document.querySelectorAll('.button'); //luam toate butoanele celelalte butoane(alea albe)
    buttons_rest.forEach(button => { //METODA ARRAY
        button.addEventListener('click', function() { //adaugam event de click
            button.style.backgroundColor = 'black';
            button.style.color = 'white'; //inversam culoarea scrisului cu cea a fundalului
        })
    });



    //eveniment de schimbare a culorii fundalului in functie de tasta apasata
    document.addEventListener('keydown', function(event) { //adaugam event de keydown
        if(event.key == 'r') { //daca apasam r se schimba in rosu
            document.body.style.backgroundColor = 'purple';
        }
        else if(event.key == 'w') { //daca apasam w se schimba inapoi in alb
            document.body.style.backgroundColor = 'white';
        }
    });
    //modificare proprietati pt paragrafu nou pt test drive
    const pTDrive= document.getElementById('testDriveP');
    pTDrive.style.padding='20px';
    pTDrive.style.fontWeight='bold';
    pTDrive.style.fontSize='18px';
    document.getElementById('testDriveDiv').style.padding='20px'; //adaugam padding pt form

    document.querySelector('input[type="submit"]').style.padding='7px 10px'; //pading pt butonul de submit
    document.querySelector('input[type="submit"]').style.backgroundColor='black'; //culoare fundal buton submit
    document.querySelector('input[type="submit"]').style.color='white'; //culoare scris buton submit

    //formular test drive
  const testDriveForm = document.getElementById('testdriveform'); //luam formularul

  testDriveForm.addEventListener('submit', function(event) { //adaugam event de submit
    event.preventDefault(); //oprim comportamentul default al formularului

    //luam valorile introduse
    const firstName = document.getElementById('fname').value;
    const firstNameInput = document.getElementById('fname');
    const lastName = document.getElementById('lname').value;
    const lastNameInput = document.getElementById('lname');
    const email = document.getElementById('email').value;
    const emailInput = document.getElementById('email');
    const phone = document.getElementById('phone').value;
    const phoneInput = document.getElementById('phone');
    const date = document.getElementById('date').value;
    const model = document.getElementById('option').value;

    const nameregex=/^[A-Za-z\s]+$/; //regex pt nume, il folosim pt ambele
    const emailregex=/^[^\s@]+@[^\s@]+\.[^\s@]+$/; //regex pt email
    const phoneregex=/^[0-9]{10}$/; //regex pt nr de tel

    //validare form cu regex

    if(!nameregex.test(firstName)) { //daca nu se potriveste cu regexul
        alert('Please enter a valid first name!'); //afisam mesaj de eroare
        firstNameInput.focus();
        return;
    }

    if(!nameregex.test(lastName)) { //daca nu se potriveste cu regexul
        alert('Please enter a valid last name!'); //afisam mesaj de eroare
        lastNameInput.focus();
        return;
    }

    if(!emailregex.test(email)) { //daca nu se potriveste cu regexul
        alert('Please enter a valid email address!'); //afisam mesaj de 
        emailInput.focus();
        return;
    }

    if(!phoneregex.test(phone)) { //daca nu se potriveste cu regexul
        alert('Please enter a valid phone number!'); //afisam mesaj de eroare
        phoneInput.focus();
        return;
    }


    // //salvare valori in localStorage
    // localStorage.setItem('firstName', firstName);
    // localStorage.setItem('lastName', lastName);
    // localStorage.setItem('email', email);
    // localStorage.setItem('phone', phone);
    // localStorage.setItem('date', date);
    // localStorage.setItem('model', model); //renunt la asta ptc salveaza un set de date,
    // daca vrem inca unul se sterge cel precedent


    //salvare valori in localStorage
    const testDriveData = JSON.parse(localStorage.getItem('testDriveData')) || []; //luam datele din localStorage
    //daca nu exista datele, cream un array gol
    const entry={firstName, lastName, email, phone, date, model, timestamp: new Date().getTime()};  //cream un obiect cu datele introduse METODA DATA
    //si adaugam timestamp ca sa stim cand s-a facut submiterea

    testDriveData.push(entry); //adaugam obiectul in array METODA ARRAY
    localStorage.setItem('testDriveData', JSON.stringify(testDriveData)); //salvam array-ul in localStorage

    alert('Thank you for booking a test drive at Audi Center! We will contact you shortly!'); //afisam mesajul de confirmare

    //resetam formularul
    testDriveForm.reset();
    });

    //setTimeout ca sa revina bckg la alb dupa 5 secunde
    setTimeout(function() {
        document.body.style.backgroundColor = 'white';}, 5000);

    //schimbare aleatoare a culorii, si dimensiunii butonului de learn more(primul)
    const par = document.getElementById('p1'); // Get the paragraph under 'Learn More'

    const randomColor = `rgb(${Math.floor(Math.random() * 256)}, ${Math.floor(Math.random() * 256)}, ${Math.floor(Math.random() * 256)})`; // Random color
    //const randomWidth = `${Math.floor(Math.random() * 61) + 15}px`; // Random width between 15 and 75
    //const randomHeight = `${Math.floor(Math.random() * 61) + 15}px`; // Random height between 15 and 75

    par.style.backgroundColor = randomColor; //schimbam culoareade bckg


    //adaugam clasa highlight la butoanele cu clasa .button daca nu o au deja, 
    //daca o au, o scoatem
    const ph = document.getElementById('highlight'); //luam toate butoanele
    ph.addEventListener('mouseover', (event) => { //adaugam event de click
        event.stopPropagation();
        const computedStyle = window.getComputedStyle(ph); //luam stilul paragrafului
        const backgroundColor = computedStyle.backgroundColor; //luam culoarea de bckg

        if(backgroundColor !== 'rgb(255, 255, 0)'){
            ph.classList.add('highlight');
        }
    });
    ph.addEventListener('mouseout', (event) => { //adaugam event de click
        event.stopPropagation();
        ph.classList.remove('highlight');}
    );

    //buton pt acesibilitate care dezactiveaza toate animatiile
    const toggleAnimations = () => {
        const body=document.body;
        const button = document.querySelector('.buton_no_animations');
        const animationStatus = document.querySelector('#animationStatus');

        body.classList.toggle('no-animations');
        //body.classList.toggle('no-hover'); //am renuntat ptc nu mai am acces la meniu drop-down si orice alt element care se folosea de hover

        if (body.classList.contains('no-animations')) {
            button.style.backgroundColor = 'red';
            button.style.color = 'black';
            animationStatus.textContent = '(ON)';
          } else {
            button.style.backgroundColor = '#000';
            button.style.color = '#fff';
            animationStatus.textContent = '(OFF)';
          }
        // if(body.classList.contains('no-animations')) {
        //     body.classList.remove('enable-animations');
        //     button.style.backgroundColor = 'red';
        //     button.style.color='black';
        //     //button.classList.toggle('disable-pointer-events');
        //     button.style.pointerEvents = 'none';
        //     animationStatus.textContent = '(ON)';
            
        // } else {
        //     body.classList.add('enable-animations');
        //     button.style.backgroundColor = 'black';
        //     button.style.color='white';
        //     //button.classList.remove('disable-pointer-events');
        //     button.style.pointerEvents = 'auto';
        //     animationStatus.textContent = '(OFF)';
        // }
    }
    const buttonA = document.querySelector('.buton_no_animations');
    buttonA.addEventListener('click', toggleAnimations);
  });



  