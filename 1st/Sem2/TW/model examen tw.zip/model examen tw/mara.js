window.onload=function(){
    
    let output = document.createElement('output');
    output.setAttribute('for', 'range');
    output.setAttribute('id', 'output');
    document.body.appendChild(output); 


    let range = document.createElement('input');
    range.setAttribute('type', 'range');
    range.setAttribute('min', '20');
    range.setAttribute('max', '150');
    range.setAttribute('value', '20');
    range.setAttribute('id', 'range');
    document.body.appendChild(range);

    

    document.body.addEventListener("keydown", keydownListener);

    function keydownListener(event) {
        let thedot=document.createElement('div');
        thedot.style.borderRadius="50%";

        //poz
        thedot.style.display="inline-block";   
        thedot.style.position="absolute";
        let w = window.innerWidth;
        let h = window.innerHeight;
        let posx = Math.floor(Math.random() * w);
        let posy = Math.floor(Math.random() * h);  
        thedot.style.left=posx+"px";
        thedot.style.top=posy+"px";

        //marime data de range
        size=document.getElementById('range').value;
        thedot.style.width=size+"px";
        thedot.style.height=size+"px";

        //culoare in functie de tasta
        if (event.key == 'b') {
            thedot.style.backgroundColor="blue";
        }
        else if(event.key == 'g'){
            thedot.style.backgroundColor="green";
        }
        else if(event.key=='y'){
            thedot.style.backgroundColor="yellow";
        }
        document.body.appendChild(thedot);
        let x=Number(localStorage.getItem('nrdots'));
        if(x==null){
            localStorage.setItem('nrdots',1);
        }
        else{
            x++;
            localStorage.setItem('nrdots',x);
        }
        output.innerHTML=x;
        
    }
    
}
